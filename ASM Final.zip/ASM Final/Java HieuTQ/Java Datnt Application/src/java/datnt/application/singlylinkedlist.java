/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java.datnt.application;

/**
 *
 * @author PC
 */
public class singlylinkedlist {
    Node head;
    
    public singlylinkedlist(){
        this.head = null;
    }
    
    public void insert(int data){
        Node new_node = new Node(data);
        
        
        if (this.head == null){
            this.head = new_node;
            
        
        } else {
            
            Node current = this.head;
            
            while(current.next != null){
                current = current.next;
            }
            current.next = new_node;
        }
    }
        public void display() {
            Node current = this.head;
            
            while(current.next != null){
                System.out.println(current.data);
                
                current = current.next;
            }
        }
        public static void main(String[] args) {
            singlylinkedlist linkedlist = new singlylinkedlist();
            
            linkedlist.insert(5);
            linkedlist.insert(10);
            linkedlist.insert(15);        
            
            linkedlist.display();
        }
    }

