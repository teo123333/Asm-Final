/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java.datnt.application;

import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class DatG {
    public static void main(String[] args) {
        ArrayList<String> a = new ArrayList<String>();
        a.add("Maria");
        a.add("John");
        a.add("Rosie");
        a.add("Lisa");
        a.add(1, "Tommy");
        a.set(0 ,"Lyly");
        a.remove(3);
        
        for(String name:a)
            System.out.println(name);
        
    }
    
}
