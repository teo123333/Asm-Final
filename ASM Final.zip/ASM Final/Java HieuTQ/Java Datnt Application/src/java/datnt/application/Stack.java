public class Stack {
    private int maxSize;
    private int top;
    private int[] stackArray;
    // Constructor to initialize stack
    public Stack(int size) {
        this.maxSize = size;
        this.stackArray = new int[maxSize];
        this.top = -1;
    }
    // Push method to add elements to the stack
    public void push(int value) {
        if (isFull()) {
            System.out.println("Stack is full. Cannot push " + value);
        } else {
            stackArray[++top] = value;
            System.out.println("Pushed " + value + " to stack.");
        }
    }
    // Pop method to remove and return the top element of the stack
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1; // Indicates stack is empty
        } else {
            int poppedValue = stackArray[top--];
            System.out.println("Popped " + poppedValue + " from stack.");
            return poppedValue;
        }
    }
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot peek.");
            return -1; // Indicates stack is empty
        } else {
            return stackArray[top];
        }
    }
    public int size() {
        return top + 1;
    }
    public boolean isEmpty() {
        return (top == -1);
    }
    public boolean isFull() {
        return (top == maxSize - 1);
    }
    public static void main(String[] args) {
        Stack stack = new Stack(5); // Create a stack with a capacity of 5 elements
        stack.push(10);
        stack.push(20);
        stack.push(30);
        System.out.println("Top element is: " + stack.peek());
        System.out.println("Stack size is: " + stack.size());
        stack.pop();
        stack.pop();
        stack.pop();
        stack.pop(); // Attempt to pop from empty stack
        System.out.println("Is stack empty? " + stack.isEmpty());
    }
}
