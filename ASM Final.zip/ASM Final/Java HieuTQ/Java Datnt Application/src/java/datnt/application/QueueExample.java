import java.util.LinkedList;
import java.util.Queue;
public class QueueExample {
    public static void main(String[] args) {
        // Khởi tạo hàng đợi để lưu trữ các công việc
        Queue<Job> jobQueue = new LinkedList<>();
        // Thêm các công việc vào hàng đợi
        jobQueue.offer(new Job("Job1"));
        jobQueue.offer(new Job("Job2"));
        jobQueue.offer(new Job("Job3"));
        jobQueue.offer(new Job("Job4"));
        // Hiển thị các công việc trong hàng đợi
        System.out.println("Jobs are expected in line:");
        System.out.println(jobQueue);
        // Lấy và xử lý các công việc từ hàng đợi
        while (!jobQueue.isEmpty()) {
            Job currentJob = jobQueue.poll();
            System.out.println("Work in progress: " + currentJob);
            // Simulate job processing
            try {
                Thread.sleep(1000); // Giả lập thời gian xử lý công việc
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("All work has been completed.");
    }
}
