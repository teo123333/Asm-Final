import java.util.Stack;
public class ReverseStringUsingStack {
    public static String reverseString(String input) {
        // Tạo một ngăn xếp để lưu các ký tự của chuỗi
        Stack<Character> stack = new Stack<>();
        // Đưa từng ký tự của chuỗi vào ngăn xếp
        for (int i = 0; i < input.length(); i++) {
            stack.push(input.charAt(i));
        }
        // Khởi tạo chuỗi kết quả để lưu kết quả sau khi đảo ngược
        StringBuilder reversed = new StringBuilder();
        // Lấy các ký tự từ ngăn xếp để tạo chuỗi đảo ngược
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }
        // Trả về chuỗi đảo ngược
        return reversed.toString();
    }
    public static void main(String[] args) {
        String input = "Hello World!";
        System.out.println("Initial string: " + input);

        String reversedString = reverseString(input);
        System.out.println("String after inversion: " + reversedString);
    }
}
