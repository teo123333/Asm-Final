import java.util.Arrays;
class DynamicArray {
    private int[] array;
    private int size;
    public DynamicArray() {
        array = new int[10];
        size = 0;
    }
    public void add(int value) {
        if (size == array.length) {
            resize();
        }
        array[size++] = value;
    }
    private void resize() {
        array = Arrays.copyOf(array, array.length * 2);
    }
    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        return array[index];
    }
    public int size() {
        return size;
    }
    public static void main(String[] args) {
        DynamicArray dynamicArray = new DynamicArray();
        // Add elements to the dynamic array
        for (int i = 1; i <= 7; i++) {
            dynamicArray.add(i);
            System.out.println("Added: " + i + ", Size: " + dynamicArray.size());
        }
        // Access and print elements from the dynamic array
        for (int i = 0; i < dynamicArray.size(); i++) {
            System.out.println("Element at index " + i + ": " + dynamicArray.get(i));
        }
    }
}
