import java.util.TreeMap;

public class StudentManagement {
    private TreeMap<String, Student> studentMap;

    public StudentManagement() {
        studentMap = new TreeMap<>();
    }

    // Existing methods...

    public Student searchStudentById(String id) {
        return studentMap.get(id); // TreeMap provides O(log n) search complexity
    }
}
