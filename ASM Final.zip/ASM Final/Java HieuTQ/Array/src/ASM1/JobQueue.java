/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ASM1;
import java.util.Queue;
import java.util.LinkedList;

/**
 *
 * @author PC
 */
public class JobQueue {
     private Queue<Job> queue;

    public JobQueue() {
        queue = new LinkedList<>();
    }

    // Phương thức để thêm một công việc vào hàng đợi (enqueue)
    public void enqueue(Job job) {
        queue.offer(job); // Sử dụng phương thức offer của Queue để thêm vào cuối hàng đợi
        System.out.println("Job '" + job.getName() + "' enqueued.");
    }

    // Phương thức để lấy một công việc từ hàng đợi (dequeue)
    public Job dequeue() {
        Job job = queue.poll(); // Sử dụng phương thức poll của Queue để lấy phần tử ở đầu hàng đợi
        if (job != null) {
            System.out.println("Job '" + job.getName() + "' dequeued.");
        } else {
            System.out.println("Queue is empty. No job to dequeue.");
        }
        return job;
    }

    // Phương thức để hiển thị các công việc trong hàng đợi
    public void displayJobs() {
        System.out.println("Jobs in the queue:");
        for (Job job : queue) {
            System.out.println(job.getName());
        }
    }

    // Phương thức để lấy số lượng công việc trong hàng đợi
    public int size() {
        return queue.size();
    }

    public static void main(String[] args) {
        JobQueue jobQueue = new JobQueue();

        // Thêm các công việc vào hàng đợi
        jobQueue.enqueue(new Job("Job1"));
        jobQueue.enqueue(new Job("Job2"));
        jobQueue.enqueue(new Job("Job3"));

        // Hiển thị các công việc trong hàng đợi
   
        // Hiển thị lại các công việc trong hàng đợi (rỗng)
        jobQueue.displayJobs();
    }
}
