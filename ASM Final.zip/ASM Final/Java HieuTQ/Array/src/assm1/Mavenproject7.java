/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assm1;

/**
 *
 * @author PC
 */
public class Mavenproject7 {
    public static void main(String[] args) {
        // Define the array
        int[] arr = {20, 8, 1, 23, 19};
        int n = arr.length;
        // Print the array before sorting
        System.out.println("Array before sorting:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
        // Apply bubble sorting algorithm
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Value swaps
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        // Print the array after sorting
        System.out.println("Array after sorting:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
