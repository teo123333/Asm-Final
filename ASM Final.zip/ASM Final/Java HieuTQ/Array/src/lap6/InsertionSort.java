import java.util.Scanner;

public class InsertionSort {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read the number of elements in the array
        int N = 5;
        int[] Arr = new int[N];

        // Read the elements of the array
        for (int i = 0; i < N; i++) {
            Arr[i] = scanner.nextInt();
        }

        // Perform insertion sort on the array
        insertionSortDescending(Arr);

        // Print the sorted array
        System.out.print("Sorted: ");
        for (int i = 0; i < N; i++) {
            if (i == N - 1) {
                System.out.print(Arr[i]);
            } else {
                System.out.print(Arr[i] + ", ");
            }
        }
    }

    // Insertion sort algorithm in descending order
    public static void insertionSortDescending(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            // Move elements of arr[0..i-1], that are less than key,
            // to one position ahead of their current position
            while (j >= 0 && arr[j] < key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }
}
